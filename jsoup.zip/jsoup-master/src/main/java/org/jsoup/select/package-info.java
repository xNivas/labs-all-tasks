/**
 Packages to support the CSS-style element selector.
 {@link org.jsoup.select.Selector Selector defines the query syntax.}
 */
@NonnullByDefault
package org.jsoup.select;

import org.jsoup.internal.NonnullByDefault;
